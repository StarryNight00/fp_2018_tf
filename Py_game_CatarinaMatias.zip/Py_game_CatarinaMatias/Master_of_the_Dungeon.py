### Pygame teste 4/5
### Catarina Matias
###a21801693

import pygame, random, sys
from pygame.locals import *

pygame.init()

#Colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)

#Defines
TEXTCOLOR = WHITE
font1 = pygame.font.SysFont(None, 36, True)
font2 = pygame.font.SysFont(None, 22)
BACKSCREEN = WHITE
SIZEWIDTH = 558
SIZEHEIGHT = 628


# Setup screen [width,height]
clock = pygame.time.Clock()
GameWindow = pygame.display.set_mode((SIZEWIDTH, SIZEHEIGHT))
GameWindow.fill(WHITE)
pygame.display.set_caption("Master of the Dungeon!")

#Lists
Swords = []


#Sprites
BG = pygame.image.load('sprites/BG.png')
RunRight = [pygame.image.load('sprites/knight-runR%s.png' % frame) for frame in range(1,4)]
RunLeft = [pygame.image.load('sprites/knight-runL%s.png' % frame) for frame in range(1,4)]
IdleRight = [pygame.image.load('sprites/knight-idleR%s.png' % frame) for frame in range(1,4)]
IdleLeft = [pygame.image.load('sprites/knight-idleL%s.png' % frame) for frame in range(1,4)]
HitRight = [pygame.image.load('sprites/knight-hitR%s.png' % frame) for frame in range(1,4)]
HitLeft = [pygame.image.load('sprites/knight-hitL%s.png' % frame) for frame in range(1,4)]
swordR = pygame.image.load('sprites/swordR.png')
swordL = pygame.image.load('sprites/swordL.png')

#Classes
class Player():
    def __init__(self, x, y, altr, larg, life):
        self.x = x
        self.y = y
        self.altr = altr
        self.larg = larg
        self.speed = 4
        self.score = 0
        self.life = life
        self.right = self.left = self.up = self.down = False
        self.walkCount = 0
        self.checkSide = 2 #1 = left, 2 = right
        self.still = True
        self.direction = 1
        self.hitbox = (self.x, self.y + 10, 30, 50)

    def draw(self, GameWindow):
        if self.walkCount + 1 >= 16:
            self.walkCount = 0
        if not (self.still):
            if self.left:
                GameWindow.blit(RunLeft[self.walkCount//8],(self.x,player.y))
            elif self.right:
                GameWindow.blit(RunRight[player.walkCount//8],(self.x,self.y))
                
            elif self.up:
                if self.checkSide == 1:
                    GameWindow.blit(RunLeft[self.walkCount//8],(self.x,self.y))
                if self.checkSide == 2:
                    GameWindow.blit(RunRight[self.walkCount//8],(self.x,self.y))
            elif self.down:
                if self.checkSide == 1:
                    GameWindow.blit(RunLeft[self.walkCount//8], (self.x,self.y))
                if self.checkSide == 2:
                    GameWindow.blit(RunRight[self.walkCount//8], (self.x,self.y))
        else:
            self.walkCount = 0
            if self.checkSide == 1:
                GameWindow.blit(IdleLeft[self.walkCount//8], (self.x,self.y))
            elif self.checkSide == 2:
                GameWindow.blit(IdleRight[self.walkCount//8],(self.x,self.y))
        self.hitbox = (self.x, self.y + 10, 30, 50)

        
    def hit(self):
        if Hit:
            if self.checkSide == 1:
                GameWindow.blit(HitLeft[self.walkCount//8],(self.x,self.y))
            if self.checkSide == 2:
                GameWindow.blit(HitRight[self.walkCount//8],(self.x,self.y))

class ThrowSword():
    def __init__(self, x, y, checkSide, direction):
        self.x = x
        self.y = y
        self.larg = 25
        self.altr = 10
        self.checkSide = 2
        self.hitbox = (self.x - 10, self.y -10, 30, 40)
        self.direction = direction
        self.speed = 8 * direction

    def draw(self, GameWindow):
        if self.checkSide == 1:
            GameWindow.blit(swordL,(self.x,self.y))
        if self.checkSide == 2:
            GameWindow.blit(swordR,(self.x,self.y))
            
        self.hitbox = (self.x - 10, self.y -10, 30, 40)
            
class EnemyX():
    RunRight = [pygame.image.load('sprites/demon-runR%s.png' % frame) for frame in range(1,4)]
    RunLeft = [pygame.image.load('sprites/demon-runL%s.png' % frame) for frame in range(1,4)]  
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.altr = 56
        self.larg = 32
        self.speed = 4
        self.end = self.x + 220
        self.life = 10
        self.visible = True
        self.path = [self.x, self.end]
        self.walkCount = 0
        self.hitbox = (self.x, self.y, 60, 50)
        
    def draw(self, GameWindow):
        self.move()
        if self.visible:
            if self.walkCount + 1 >= 16:
                self.walkCount = 0

            if self.speed > 0:
                GameWindow.blit(self.RunRight[self.walkCount//8], (self.x,self.y))
                self.walkCount += 1
            else:
                GameWindow.blit(self.RunLeft[self.walkCount//8], (self.x,self.y))
                self.walkCount += 1
            pygame.draw.rect (GameWindow, RED, (self.hitbox[0], self.hitbox[1] - 20, 50, 10))
            pygame.draw.rect (GameWindow, (0, 255,0), (self.hitbox[0], self.hitbox[1] - 20, 50 - ((50/10)*(10-self.life)), 10))
            self.hitbox = (self.x, self.y, 40, 50)
            
    def move(self):
        if self.speed > 0:
            if self.x + self.speed < self.path[1]:
                self.x += self.speed
            else:
                self.speed = self.speed * -1
                self.walkCount = 0
        else:
            if self.x -self.speed > self.path[0]:
                self.x += self.speed
            else:
                self.speed = self.speed * -1
                self.walkCount = 0
    def hit(self):
        if self.life > 0:
            self.life -= 1
        else:
            self.visible = False
        

class EnemyY():
    RunRight = [pygame.image.load('sprites/zombie-runR%s.png' % frame) for frame in range(1,4)]
    RunLeft = [pygame.image.load('sprites/zombie-runL%s.png' % frame) for frame in range(1,4)]

    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.altr = 24
        self.larg = 24
        self.speed = 4
        self.end = self.y + 200
        self.life = 10
        self.visible = True
        self.path = [self.y, self.end]
        self.walkCount = 0
        self.hitbox = (self.x, self.y, 40, 25)
        
    def draw(self, GameWindow):
        self.move()
        if self.visible:
            if self.walkCount + 1 >= 16:
                self.walkCount = 0

            if self.speed > 0:
                GameWindow.blit(self.RunRight[self.walkCount//8], (self.x,self.y))
                self.walkCount += 1
            else:
                GameWindow.blit(self.RunLeft[self.walkCount//8], (self.x,self.y))
                self.walkCount += 1
            pygame.draw.rect (GameWindow, RED, (self.hitbox[0], self.hitbox[1] - 20, 50, 10))
            pygame.draw.rect (GameWindow, (0, 255,0), (self.hitbox[0], self.hitbox[1] - 20, 50 - ((50/10)*(10-self.life)), 10))
            self.hitbox = (self.x, self.y, 40, 50)

            
    def move(self):
        if self.speed > 0:
            if self.y + self.speed < self.path[1]:
                self.y += self.speed
            else:
                self.speed = self.speed * -1
                self.walkCount = 0
        else:
            if self.y -self.speed > self.path[0]:
                self.y += self.speed
            else:
                self.speed = self.speed * -1
                self.walkCount = 0
    def hit(self):
        if self.life > 0:
            self.life -= 1
        else:
            self.visible = False
        
#Functions

def EndGame():
    End = True
    pygame.quit()
    sys.exit()

def RedrawGameWin():
    GameWindow.blit(BG, (0,0))
    player.draw(GameWindow)
    
    demon1.draw(GameWindow)
    demon2.draw(GameWindow)
    demon3.draw(GameWindow)
    zombie1.draw(GameWindow)
    zombie2.draw(GameWindow)
    zombie3.draw(GameWindow)

    text = font1.render('Score: %s' % player.score, 1, TEXTCOLOR)
    GameWindow.blit(text, (410,20))
    
    for sword in Swords:
        sword.draw(GameWindow)

    pygame.display.update()

#Game
End = False
Hit = False
shootLoop = 0
player = Player(10, 0, 56, 32, 50)
sword = ThrowSword (player.x, player.y, player.checkSide, player.direction)
demon1 = EnemyX(random.randint(10, 398), random.randint(20, 548))
demon2 = EnemyX(random.randint(10, 398), random.randint(20, 548))
demon3 = EnemyX(random.randint(10, 398), random.randint(20, 548))
zombie1 = EnemyY(random.randint(10, 538), random.randint(20, 408))
zombie2 = EnemyY(random.randint(10, 538), random.randint(20, 408))
zombie3 = EnemyY(random.randint(10, 538), random.randint(20, 408))


while End != True:
    clock.tick(32)

    if shootLoop > 0:
        shootLoop += 1
    if shootLoop > 4:
        shootLoop = 0

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            EndGame()

    keys = pygame.key.get_pressed()

    if keys[pygame.K_SPACE] and shootLoop == 0:
        if player.checkSide == 1:
            sword.checkSide = 1
            sword.direction = -1
        elif player.checkSide == 2:
            sword.checkSide = 2
            sword.direction = 1
        if len(Swords) < 200:
            Swords.append(ThrowSword(round(player.x + player.larg //2), round(player.y + player.altr //2), player.checkSide, sword.direction))

        shootLoop = 1

    for sword in Swords:
        if sword.x < 550 and sword.x > 0:
            sword.x += sword.speed
        else :
            Swords.pop(Swords.index(sword))

        if sword.y - sword.larg < demon1.hitbox[1] + demon1.hitbox[3] and sword.y + sword.larg > demon1.hitbox[1]:
            if sword.x + sword.altr > demon1.hitbox[0] and sword.x - sword.altr < demon1.hitbox[0] + demon1.hitbox[2]:
                player.score += 3
                demon1.hit()
                demon1.life -= 1
                Swords.pop(Swords.index(sword))
                    
        if sword.y - sword.larg < demon2.hitbox[1] + demon2.hitbox[3] and sword.y + sword.larg > sword.hitbox[1]:
            if sword.x + sword.altr > demon2.hitbox[0] and sword.x - sword.altr < demon2.hitbox[0] + demon2.hitbox[2]:
                player.score += 3
                demon2.hit()
                demon2.life -= 1
                Swords.pop(Swords.index(sword))
                        
        if sword.y - sword.larg < demon3.hitbox[1] + demon3.hitbox[3] and sword.y + sword.larg > demon3.hitbox[1]:
            if sword.x + sword.altr > demon3.hitbox[0] and sword.x - sword.altr < demon3.hitbox[0] + demon3.hitbox[2]:
                player.score += 3
                demon3.hit()
                demon3.life -= 1
                Swords.pop(Swords.index(sword))
                        
        if sword.y - sword.larg < zombie1.hitbox[1] + zombie1.hitbox[3] and zombie1.y + sword.larg > zombie1.hitbox[1]:
            if sword.x + sword.altr > zombie1.hitbox[0] and sword.x - sword.altr < zombie1.hitbox[0] + zombie1.hitbox[2]:
                player.score += 1
                zombie1.hit()
                zombie1.life -= 1
                Swords.pop(Swords.index(sword))
                        
        if sword.y - sword.larg < zombie2.hitbox[1] + zombie2.hitbox[3] and sword.y + sword.larg > zombie2.hitbox[1]:
            if sword.x + sword.altr > zombie2.hitbox[0] and sword.x - sword.altr < zombie2.hitbox[0] + zombie2.hitbox[2]:
                player.score += 2
                zombie2.hit()
                zombie2.life -= 1
                Swords.pop(Swords.index(sword))
                        
        if sword.y - sword.larg < zombie3.hitbox[1] + zombie3.hitbox[3] and sword.y + sword.larg > zombie3.hitbox[1]:
            if sword.x + sword.altr > zombie3.hitbox[0] and sword.x - sword.altr < zombie3.hitbox[0] + zombie3.hitbox[2]:
                player.score += 2
                zombie3.hit()
                zombie3.life -= 1
                Swords.pop(Swords.index(sword))

    if keys[pygame.K_LEFT] and player.x > player.speed:
        player.x -= player.speed
        player.left = True
        player.right = False
        player.still = False
        player.walkCount += 1
        player.checkSide = 1
    elif keys[pygame.K_RIGHT] and player.x < SIZEWIDTH - player.larg - player.speed:
        player.x += player.speed
        player.right = True
        player.left = False
        player.still = False
        player.walkCount += 1
        player.checkSide = 2
    else:
        player.right = False
        player.left = False
        player.still = True
        player.walkCount = 0
        
    if keys[pygame.K_UP] and player.y > player.speed:
        player.y -= player.speed
        player.up = True
        player.down = False
        player.still = False
    elif keys[pygame.K_DOWN] and player.y < SIZEHEIGHT - player.altr - 15:
        player.y += player.speed
        player.down = True
        player.up = False
        player.still = False
    else:
        player.up = False
        player.down = False
        player.still = True
        player.walkCount = 0

    if player.y - player.larg < demon1.hitbox[1] + demon1.hitbox[3] and player.y + player.larg > demon1.hitbox[1]:
            if player.x + player.altr > demon1.hitbox[0] and player.x - player.altr < demon1.hitbox[0] + demon1.hitbox[2]:
                Hit = True
                player.life -= 1
                player.hit()
                Hit = False
                
    if player.y - player.larg < demon2.hitbox[1] + demon2.hitbox[3] and player.y + player.larg > demon2.hitbox[1]:
            if player.x + player.altr > demon2.hitbox[0] and player.x - player.altr < demon2.hitbox[0] + demon2.hitbox[2]:
                Hit = True
                player.life -= 1
                player.hit()
                Hit = False
                
    if player.y - player.larg < demon3.hitbox[1] + demon3.hitbox[3] and player.y + player.larg > demon3.hitbox[1]:
            if player.x + player.altr > demon3.hitbox[0] and player.x - player.altr < demon3.hitbox[0] + demon3.hitbox[2]:
                Hit = True
                player.life -= 1
                player.hit()
                Hit = False

    if player.y - player.larg < zombie1.hitbox[1] + zombie1.hitbox[3] and zombie1.y + player.larg > zombie1.hitbox[1]:
            if player.x + player.altr > zombie1.hitbox[0] and player.x - player.altr < zombie1.hitbox[0] + zombie1.hitbox[2]:
                Hit = True
                player.life -= 1
                player.hit()
                Hit = False
                
    if player.y - player.larg < zombie2.hitbox[1] + zombie2.hitbox[3] and player.y + player.larg > zombie2.hitbox[1]:
            if player.x + player.altr > zombie2.hitbox[0] and player.x - player.altr < zombie2.hitbox[0] + zombie2.hitbox[2]:
                Hit = True
                player.life -= 1
                player.hit()
                Hit = False
                
    if player.y - player.larg < zombie3.hitbox[1] + zombie3.hitbox[3] and player.y + player.larg > zombie3.hitbox[1]:
            if player.x + player.altr > zombie3.hitbox[0] and player.x - player.altr < zombie3.hitbox[0] + zombie3.hitbox[2]:
                Hit = True
                player.life -= 1
                player.hit()
                Hit = False

    

    RedrawGameWin()
    if demon1.visible == False and demon2.visible == False and demon3.visible == False and zombie1.visible == False and zombie2.visible == False and zombie3.visible == False:
        GameWindow.fill(BLACK)
        text1 = font1.render('You have won!', 1, TEXTCOLOR)
        GameWindow.blit(text, (250,20))
        text2 = font1.render('Score: %s' % player.score, 1, TEXTCOLOR)
        GameWindow.blit(text, (280,60))
        End = True
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                EndGame()
        pygame.display.update()


    if player.life <= 0:
        GameWindow.fill(BLACK)
        text1 = font1.render('You have lost!', 1, TEXTCOLOR)
        GameWindow.blit(text, (250,20))
        text2 = font1.render('Score: %s' % player.score, 1, TEXTCOLOR)
        GameWindow.blit(text, (280,60))
        End = True
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                EndGame()
        pygame.display.update()

pygame.quit()
