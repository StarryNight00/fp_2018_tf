Catarina Matias
a21801693
Fundamentos de Programa��o, teste 4/5

Sprites retiradas de
https://0x72.itch.io/dungeontileset-ii

Regras:
> Movimentar o player e desviar-se dos monstros - up, down, left, right.
> Disparar contra os monstros - space bar
> Um monstro grande vale 3 pontos por tiro, e um pequeno 2 - as barras indicam a vida

